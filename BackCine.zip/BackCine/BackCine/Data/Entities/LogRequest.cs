﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackCine.Data.Entities
{
    public class LogRequest
    {
        public string Email { get; set; }
        public string Contrasenha { get; set; }
    }
}
